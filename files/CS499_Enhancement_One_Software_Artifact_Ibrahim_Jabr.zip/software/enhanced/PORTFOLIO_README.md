# CS 360 – Mobile App Portfolio Artifact

This repo contains my completed app from CS 360: the **Sensor Demo** app (Project Three). The ZIP in this repo has the full Android Studio project, including the app code and the UI layout used for the app.

---

## Journal Responses (Module Eight)

### Briefly summarize the requirements and goals of the app you developed. What user needs was this app designed to address?

The app had to use Android’s SensorManager to read one hardware sensor and show the values on screen or in the console. I picked the accelerometer because it’s easy to see the numbers change and it works in the emulator. The goal was to show that I could get sensor data, display it, and log it. So the “user need” here was mainly a learning and assignment need: prove the app can talk to a sensor and show the data in a simple way.

### What screens and features were necessary to support user needs and produce a user-centered UI for the app? How did your UI designs keep users in mind? Why were your designs successful?

There’s one main screen. It shows a title (Accelerometer), the three values (X, Y, Z), and a short hint so someone opening the app knows they can tilt the device or use emulator controls to see changes. I kept the layout simple and centered so the numbers are easy to read. No extra buttons or menus. For this kind of demo, that was enough—users get the info they need without clutter.

### How did you approach the process of coding your app? What techniques or strategies did you use? How could those techniques or strategies be applied in the future?

I started with the structure: one activity, one layout, and the SensorManager setup. I got the system service, asked for the accelerometer, and registered a listener so the app gets updates. I made sure to register in onResume and unregister in onPause so we don’t leak listeners. I also added null checks so the app doesn’t crash if the sensor isn’t there. In the future I’d use the same approach: get the structure right first, then add safety checks and keep lifecycle in mind.

### How did you test to ensure your code was functional? Why is this process important, and what did it reveal?

I ran the app in the Android Emulator and watched the X, Y, Z values on screen. I used the emulator’s virtual sensor controls to change the accelerometer and confirmed the numbers updated. I also set breakpoints in the sensor callback and in the method that updates the UI to see when and where the values change. Testing like this is important because it shows the app really works and that the data flow from sensor to screen is correct. It also makes it easier to debug if something goes wrong later.

### Consider the full app design and development process from initial planning to finalization. Where did you have to innovate to overcome a challenge?

One challenge was making sure the app didn’t register the sensor listener twice (e.g. in both onCreate and onResume), which could waste resources. I fixed it by only registering in onResume and unregistering in onPause, which is the usual Android pattern. Another was handling devices or emulators that might not have an accelerometer—so I added checks and showed a simple message instead of crashing. Small changes, but they made the app more robust.

### In what specific component of your mobile app were you particularly successful in demonstrating your knowledge, skills, and experience?

I’d say the SensorManager integration and the lifecycle handling. The app correctly gets the system service, requests the accelerometer, registers and unregisters the listener at the right times, and updates the UI on the main thread while also logging to the console. That shows I can use the Android sensor API and follow basic lifecycle and threading practices in a real app.

---

*CS 360 Module Eight Portfolio Submission*
