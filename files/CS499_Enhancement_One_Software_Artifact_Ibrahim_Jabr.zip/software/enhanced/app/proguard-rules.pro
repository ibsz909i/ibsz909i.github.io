# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in /usr/local/Cellar/android-commandlinetools/...
# You can edit the include path and order by changing the proguardFiles
# directive in build.gradle.
