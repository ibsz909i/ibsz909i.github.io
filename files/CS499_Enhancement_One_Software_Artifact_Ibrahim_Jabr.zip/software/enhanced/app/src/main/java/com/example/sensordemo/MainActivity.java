package com.example.sensordemo;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "SensorDemo";

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private TextView textX;
    private TextView textY;
    private TextView textZ;
    private TextView textStatus;
    private TextView textMagnitude;
    private TextView textPeak;
    private float lastX;
    private float lastY;
    private float lastZ;
    private float currentMagnitude;
    private float peakMagnitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textX = findViewById(R.id.value_x);
        textY = findViewById(R.id.value_y);
        textZ = findViewById(R.id.value_z);
        textStatus = findViewById(R.id.sensor_status);
        textMagnitude = findViewById(R.id.value_magnitude);
        textPeak = findViewById(R.id.value_peak);
        Button resetButton = findViewById(R.id.reset_peak_button);

        resetButton.setOnClickListener(view -> {
            peakMagnitude = currentMagnitude;
            updateUI();
        });

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) {
            textStatus.setText(R.string.no_sensor_service);
            return;
        }

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer == null) {
            textStatus.setText(R.string.no_accelerometer);
            return;
        }

        textStatus.setText(getString(R.string.sensor_ready));
        updateUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            textStatus.setText(getString(R.string.sensor_listening));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        if (accelerometer != null) {
            textStatus.setText(getString(R.string.sensor_paused));
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event == null || event.values == null || event.values.length < 3) {
            return;
        }
        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) {
            return;
        }

        lastX = event.values[0];
        lastY = event.values[1];
        lastZ = event.values[2];
        currentMagnitude = (float) Math.sqrt((lastX * lastX) + (lastY * lastY) + (lastZ * lastZ));
        if (currentMagnitude > peakMagnitude) {
            peakMagnitude = currentMagnitude;
        }

        runOnUiThread(this::updateUI);
        Log.d(TAG, "accel x=" + lastX + " y=" + lastY + " z=" + lastZ + " magnitude=" + currentMagnitude);
    }

    private void updateUI() {
        textX.setText(SensorReadingFormatter.formatAxis("X", lastX));
        textY.setText(SensorReadingFormatter.formatAxis("Y", lastY));
        textZ.setText(SensorReadingFormatter.formatAxis("Z", lastZ));
        textMagnitude.setText(SensorReadingFormatter.formatMagnitude("Current movement", currentMagnitude));
        textPeak.setText(SensorReadingFormatter.formatMagnitude("Peak movement", peakMagnitude));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}
