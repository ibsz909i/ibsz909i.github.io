package com.example.sensordemo;

import java.util.Locale;

public final class SensorReadingFormatter {

    private SensorReadingFormatter() {
    }

    public static String formatAxis(String axis, float value) {
        return String.format(Locale.US, "%s: %.2f", axis, value);
    }

    public static String formatMagnitude(String label, float value) {
        return String.format(Locale.US, "%s: %.2f", label, value);
    }
}
