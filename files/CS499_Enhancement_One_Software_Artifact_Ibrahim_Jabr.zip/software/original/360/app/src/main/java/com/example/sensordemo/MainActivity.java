package com.example.sensordemo;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "SensorDemo";

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private TextView textX, textY, textZ;
    private float lastX, lastY, lastZ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textX = findViewById(R.id.value_x);
        textY = findViewById(R.id.value_y);
        textZ = findViewById(R.id.value_z);

        // grab the sensor manager and the accelerometer
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) {
            textX.setText(R.string.no_sensor_service);
            return;
        }
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer == null) {
            textX.setText(R.string.no_accelerometer);
        }
        // listener registration happens in onResume so we don't double-register
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event == null || event.values == null || event.values.length < 3) return;
        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;

        lastX = event.values[0];
        lastY = event.values[1];
        lastZ = event.values[2];

        // update screen and write to logcat
        runOnUiThread(this::updateUI);
        Log.d(TAG, "accel x=" + lastX + " y=" + lastY + " z=" + lastZ);
    }

    private void updateUI() {
        textX.setText(String.format(Locale.US, "X: %.2f", lastX));
        textY.setText(String.format(Locale.US, "Y: %.2f", lastY));
        textZ.setText(String.format(Locale.US, "Z: %.2f", lastZ));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // not needed for this demo
    }
}
