import os

from bson.objectid import ObjectId
from pymongo import MongoClient


class AnimalShelter(object):
    def __init__(
        self,
        username=None,
        password=None,
        host="localhost",
        port=27017,
        database="aac",
        collection="animals",
    ):
        user = username or os.getenv("AAC_USERNAME") or "aacuser"
        password_value = password or os.getenv("AAC_PASSWORD") or "SNHU1234"

        self.client = MongoClient(
            f"mongodb://{user}:{password_value}@{host}:{port}/{database}",
            serverSelectionTimeoutMS=5000,
        )
        self.database = self.client[database]
        self.collection = self.database[collection]

    def _normalize_query(self, query):
        if query is None:
            return {}
        if not isinstance(query, dict):
            raise TypeError("Query parameter must be a dictionary")

        normalized_query = dict(query)
        if "_id" in normalized_query and isinstance(normalized_query["_id"], str):
            try:
                normalized_query["_id"] = ObjectId(normalized_query["_id"])
            except Exception:
                pass

        return normalized_query

    def create(self, data):
        if not isinstance(data, dict) or not data:
            raise Exception("Nothing to save, because data parameter is empty")

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except Exception as e:
            print(f"An error occurred during insert: {e}")
            return False

    def read(self, query=None, projection=None, sort=None, limit=0):
        try:
            cursor = self.collection.find(self._normalize_query(query), projection)

            if sort:
                cursor = cursor.sort(sort)
            if limit:
                cursor = cursor.limit(limit)

            return list(cursor)
        except Exception as e:
            print(f"An error occurred during read: {e}")
            return []

    def update(self, query, data):
        if not isinstance(data, dict) or not data:
            raise Exception("Nothing to update, because data parameter is empty")

        try:
            result = self.collection.update_many(
                self._normalize_query(query), {"$set": data}
            )
            return result.modified_count
        except Exception as e:
            print(f"An error occurred during update: {e}")
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(self._normalize_query(query))
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred during delete: {e}")
            return 0
