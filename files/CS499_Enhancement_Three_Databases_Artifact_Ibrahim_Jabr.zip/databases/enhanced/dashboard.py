import re

import dash_leaflet as dl
import pandas as pd
import plotly.express as px
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output
from jupyter_dash import JupyterDash

from animal_shelter import AnimalShelter

JupyterDash.infer_jupyter_proxy_config()


def build_breed_filter(breeds):
    return [{"breed": {"$regex": re.escape(breed), "$options": "i"}} for breed in breeds]


RESCUE_FILTERS = {
    "all": {},
    "water": {
        "animal_type": "Dog",
        "sex_upon_outcome": "Intact Female",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        "$or": build_breed_filter(
            ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]
        ),
    },
    "mountain": {
        "animal_type": "Dog",
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        "$or": build_breed_filter(
            [
                "German Shepherd",
                "Alaskan Malamute",
                "Old English Sheepdog",
                "Siberian Husky",
                "Rottweiler",
            ]
        ),
    },
    "disaster": {
        "animal_type": "Dog",
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
        "$or": build_breed_filter(
            [
                "Doberman Pinscher",
                "German Shepherd",
                "Golden Retriever",
                "Bloodhound",
                "Rottweiler",
            ]
        ),
    },
}

DISPLAY_COLUMNS = [
    "animal_id",
    "name",
    "animal_type",
    "breed",
    "color",
    "sex_upon_outcome",
    "age_upon_outcome",
    "age_upon_outcome_in_weeks",
    "outcome_type",
    "location_lat",
    "location_long",
]

FILTER_OPTIONS = [
    {"label": "All Animals", "value": "all"},
    {"label": "Water Rescue", "value": "water"},
    {"label": "Mountain or Wilderness Rescue", "value": "mountain"},
    {"label": "Disaster or Individual Tracking", "value": "disaster"},
]

shelter = AnimalShelter()


def load_dashboard_data(filter_name="all"):
    query = RESCUE_FILTERS.get(filter_name, {})
    projection = {column: 1 for column in DISPLAY_COLUMNS}
    projection["_id"] = 0

    records = shelter.read(query=query, projection=projection, sort=[("breed", 1)])
    frame = pd.DataFrame.from_records(records)

    if frame.empty:
        return pd.DataFrame(columns=DISPLAY_COLUMNS)

    for column in DISPLAY_COLUMNS:
        if column not in frame.columns:
            frame[column] = ""

    return frame[DISPLAY_COLUMNS]


def build_columns(frame):
    return [
        {
            "name": column.replace("_", " ").title(),
            "id": column,
            "deletable": False,
            "selectable": True,
        }
        for column in frame.columns
    ]


def empty_figure(title, message):
    figure = px.bar(title=title)
    figure.update_xaxes(visible=False)
    figure.update_yaxes(visible=False)
    figure.add_annotation(text=message, showarrow=False, x=0.5, y=0.5, xref="paper", yref="paper")
    figure.update_layout(plot_bgcolor="white", paper_bgcolor="white")
    return figure


df = load_dashboard_data()

app = JupyterDash("GraziosoSalvareDashboard")

app.layout = html.Div(
    [
        html.Center(html.B(html.H1("Grazioso Salvare Dashboard"))),
        html.Hr(),
        html.Div(
            [
                html.Label("Rescue Training Filter"),
                dcc.RadioItems(
                    id="rescue-filter",
                    options=FILTER_OPTIONS,
                    value="all",
                    inline=True,
                    labelStyle={"marginRight": "20px"},
                ),
            ]
        ),
        html.Br(),
        dash_table.DataTable(
            id="datatable-id",
            columns=build_columns(df),
            data=df.to_dict("records"),
            page_size=10,
            sort_action="native",
            row_selectable="single",
            selected_rows=[0] if not df.empty else [],
            filter_action="native",
            style_cell={"textAlign": "left", "padding": "8px"},
            style_data={"whiteSpace": "normal", "height": "auto"},
            style_table={"overflowX": "auto"},
        ),
        html.Br(),
        dcc.Graph(id="chart-id"),
        html.Div(id="map-id"),
    ]
)


@app.callback(
    Output("datatable-id", "data"),
    Output("datatable-id", "columns"),
    Output("datatable-id", "selected_rows"),
    Input("rescue-filter", "value"),
)
def update_table(filter_name):
    frame = load_dashboard_data(filter_name)
    selected_rows = [0] if not frame.empty else []
    return frame.to_dict("records"), build_columns(frame), selected_rows


@app.callback(
    Output("datatable-id", "style_data_conditional"),
    Input("datatable-id", "selected_rows"),
)
def update_styles(selected_rows):
    if not selected_rows:
        return []

    return [
        {
            "if": {"row_index": row},
            "background_color": "#D2F3FF",
        }
        for row in selected_rows
    ]


@app.callback(
    Output("chart-id", "figure"),
    Input("datatable-id", "derived_virtual_data"),
)
def update_chart(view_data):
    if not view_data:
        return empty_figure("Breed Summary", "No data available for the current filter.")

    frame = pd.DataFrame.from_dict(view_data)
    if frame.empty or "breed" not in frame.columns:
        return empty_figure("Breed Summary", "No breed data available.")

    breed_counts = (
        frame["breed"]
        .fillna("Unknown")
        .replace("", "Unknown")
        .value_counts()
        .head(10)
        .reset_index()
    )
    breed_counts.columns = ["breed", "count"]

    figure = px.bar(
        breed_counts,
        x="count",
        y="breed",
        orientation="h",
        title="Top Breeds in Current View",
        labels={"count": "Count", "breed": "Breed"},
    )
    figure.update_layout(yaxis={"categoryorder": "total ascending"})
    return figure


@app.callback(
    Output("map-id", "children"),
    Input("datatable-id", "derived_virtual_data"),
    Input("datatable-id", "derived_virtual_selected_rows"),
)
def update_map(view_data, selected_rows):
    if not view_data:
        return html.Div("No data available.")

    frame = pd.DataFrame.from_dict(view_data)
    if frame.empty:
        return html.Div("No data available.")

    row_index = selected_rows[0] if selected_rows else 0
    if row_index >= len(frame):
        row_index = 0

    row = frame.iloc[row_index]
    latitude = row.get("location_lat")
    longitude = row.get("location_long")

    if pd.isna(latitude) or pd.isna(longitude):
        return html.Div("Location data not available for the selected entry.")

    name = row.get("name") or "Unknown"
    breed = row.get("breed") or "Unknown"
    animal_id = row.get("animal_id") or "N/A"

    return [
        dl.Map(
            style={"width": "100%", "height": "500px"},
            center=[float(latitude), float(longitude)],
            zoom=10,
            children=[
                dl.TileLayer(id="base-layer-id"),
                dl.Marker(
                    position=[float(latitude), float(longitude)],
                    children=[
                        dl.Tooltip(f"{name} - {breed}"),
                        dl.Popup(
                            [
                                html.H2(name),
                                html.P(f"Breed: {breed}"),
                                html.P(f"Animal ID: {animal_id}"),
                            ]
                        ),
                    ],
                ),
            ],
        )
    ]


if __name__ == "__main__":
    app.run_server(debug=True, port=8050)
