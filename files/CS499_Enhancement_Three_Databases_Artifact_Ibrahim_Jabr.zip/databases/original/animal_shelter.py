from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username=None, password=None):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        
        # If the dashboard provides a username/pass, use them.
        # Otherwise, default to the hardcoded values (good for testing).
        if username and password:
            USER = username
            PASS = password
        else:
            USER = 'aacuser'
            PASS = 'SNHU1234'
            
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
        
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """
        Method to implement the C in CRUD.
        Inserts a document into the specified MongoDB database and collection.
        :param data: A dictionary containing key/value pairs for the document.
        :return: True if successful, False otherwise.
        """
        if data is not None:
            try:
                self.collection.insert_one(data)  # data should be dictionary
                return True
            except Exception as e:
                print(f"An error occurred during insert: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """
        Method to implement the R in CRUD.
        Queries for document(s) from the specified MongoDB database and collection.
        :param query: A dictionary containing key/value pairs for lookup.
        :return: A list of documents if successful, or an empty list.
        """
        try:
            if query is not None:
                # Retrieve the documents as a list of dictionaries
                result = list(self.collection.find(query))
                return result
            else:
                return []
        except Exception as e:
            print(f"An error occurred during read: {e}")
            return []

    def update(self, query, data):
        """
        Method to implement the U in CRUD.
        Queries for and changes document(s) from the specified MongoDB database and collection.
        :param query: A dictionary for lookup (filter).
        :param data: A dictionary containing key/value pairs to update.
        :return: The number of objects modified.
        """
        if query is not None:
            try:
                # update_many allows for multiple documents to be updated
                result = self.collection.update_many(query, {"$set": data})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            raise Exception("Nothing to update, because query parameter is empty")

    def delete(self, query):
        """
        Method to implement the D in CRUD.
        Queries for and removes document(s) from the specified MongoDB database and collection.
        :param query: A dictionary for lookup (filter).
        :return: The number of objects removed.
        """
        if query is not None:
            try:
                # delete_many allows for multiple documents to be deleted
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during delete: {e}")
                return 0
        else:
            raise Exception("Nothing to delete, because query parameter is empty")

