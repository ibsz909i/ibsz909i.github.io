import json
import random
from collections import deque
from pathlib import Path

import numpy as np

from TreasureMaze import DOWN, LEFT, RIGHT, UP, TreasureMaze


MAZE = np.array(
    [
        [1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
        [1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0],
        [1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0],
        [1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0],
        [1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0],
        [1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0],
        [1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0],
        [1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0],
    ]
)

ACTION_NAMES = {
    LEFT: "left",
    UP: "up",
    RIGHT: "right",
    DOWN: "down",
}


def state_to_index(cell, width):
    return cell[0] * width + cell[1]


def index_to_state(index, width):
    return divmod(index, width)


def choose_action(q_table, state_index, valid_actions, epsilon):
    if random.random() < epsilon:
        return random.choice(valid_actions)
    return max(valid_actions, key=lambda action: q_table[state_index, action])


def train_q_learning(maze, n_epochs=1200, alpha=0.2, gamma=0.9, epsilon_decay=0.995):
    qmaze = TreasureMaze(maze)
    width = maze.shape[1]
    q_table = np.zeros((maze.size, 4))
    epsilon = 1.0
    epsilon_min = 0.01
    win_history = []

    for _ in range(n_epochs):
        start_cell = random.choice(qmaze.free_cells)
        qmaze.reset(start_cell)
        state_index = state_to_index(start_cell, width)

        for _ in range(200):
            valid_actions = qmaze.valid_actions()
            if not valid_actions:
                win_history.append(0)
                break

            action = choose_action(q_table, state_index, valid_actions, epsilon)
            _, reward, status = qmaze.act(action)
            row, col, _ = qmaze.state
            next_state_index = state_to_index((row, col), width)

            q_table[state_index, action] += alpha * (
                reward + gamma * np.max(q_table[next_state_index]) - q_table[state_index, action]
            )
            state_index = next_state_index

            if status == "win":
                win_history.append(1)
                break
            if status == "lose":
                win_history.append(0)
                break

        epsilon = max(epsilon_min, epsilon * epsilon_decay)

    return q_table, win_history


def policy_path(q_table, maze, start_cell, max_steps=100):
    qmaze = TreasureMaze(maze)
    qmaze.reset(start_cell)
    width = maze.shape[1]
    path = [start_cell]
    actions = []

    for _ in range(max_steps):
        valid_actions = qmaze.valid_actions()
        if not valid_actions:
            return path, actions, False

        state_index = state_to_index((qmaze.state[0], qmaze.state[1]), width)
        action = max(valid_actions, key=lambda option: q_table[state_index, option])
        actions.append(ACTION_NAMES[action])
        _, _, status = qmaze.act(action)
        current_cell = (qmaze.state[0], qmaze.state[1])
        path.append(current_cell)

        if status == "win":
            return path, actions, True
        if status == "lose":
            return path, actions, False

    return path, actions, False


def bfs_shortest_path(maze, start_cell):
    target = (maze.shape[0] - 1, maze.shape[1] - 1)
    queue = deque([start_cell])
    parents = {start_cell: None}

    while queue:
        row, col = queue.popleft()
        if (row, col) == target:
            break

        neighbors = []
        if col > 0 and maze[row, col - 1] == 1.0:
            neighbors.append((row, col - 1))
        if row > 0 and maze[row - 1, col] == 1.0:
            neighbors.append((row - 1, col))
        if col < maze.shape[1] - 1 and maze[row, col + 1] == 1.0:
            neighbors.append((row, col + 1))
        if row < maze.shape[0] - 1 and maze[row + 1, col] == 1.0:
            neighbors.append((row + 1, col))

        for neighbor in neighbors:
            if neighbor not in parents:
                parents[neighbor] = (row, col)
                queue.append(neighbor)

    if target not in parents:
        return []

    path = []
    current = target
    while current is not None:
        path.append(current)
        current = parents[current]
    path.reverse()
    return path


def evaluate_policy(q_table, maze):
    qmaze = TreasureMaze(maze)
    evaluations = []

    for cell in qmaze.free_cells:
        learned_path, learned_actions, success = policy_path(q_table, maze, cell)
        optimal_path = bfs_shortest_path(maze, cell)
        evaluations.append(
            {
                "start_cell": list(cell),
                "success": success,
                "learned_steps": max(0, len(learned_path) - 1),
                "optimal_steps": max(0, len(optimal_path) - 1),
                "path_gap": max(0, len(learned_path) - len(optimal_path)),
                "actions": learned_actions,
            }
        )

    successes = [item for item in evaluations if item["success"]]
    success_rate = len(successes) / len(evaluations) if evaluations else 0.0
    average_learned_steps = (
        sum(item["learned_steps"] for item in successes) / len(successes) if successes else 0.0
    )
    average_optimal_steps = (
        sum(item["optimal_steps"] for item in successes) / len(successes) if successes else 0.0
    )

    return {
        "success_rate": round(success_rate, 3),
        "average_learned_steps": round(average_learned_steps, 2),
        "average_optimal_steps": round(average_optimal_steps, 2),
        "evaluations": evaluations,
    }


def main():
    random.seed(7)
    np.random.seed(7)

    q_table, win_history = train_q_learning(MAZE)
    results = evaluate_policy(q_table, MAZE)
    results["training_episodes"] = len(win_history)
    results["wins"] = int(sum(win_history))
    results["losses"] = int(len(win_history) - sum(win_history))

    output_path = Path(__file__).with_name("enhanced_treasure_maze_results.json")
    output_path.write_text(json.dumps(results, indent=2))

    print("Training episodes:", results["training_episodes"])
    print("Wins:", results["wins"])
    print("Losses:", results["losses"])
    print("Success rate:", results["success_rate"])
    print("Average learned steps:", results["average_learned_steps"])
    print("Average optimal steps:", results["average_optimal_steps"])
    print("Results saved to:", output_path)


if __name__ == "__main__":
    main()
