"""
GameExperience.py - Experience Replay Memory for Deep Q-Learning

This class stores episodes (state transitions) and provides methods for
experience replay training. It stores tuples of (state, action, reward, next_state, done)
and can sample batches for training the neural network.
"""

import numpy as np
import random

class GameExperience:
    def __init__(self, model, target_model=None, max_memory=1000, discount=0.95):
        self.model = model
        self.target_model = target_model if target_model else model
        self.max_memory = max_memory
        self.discount = discount
        self.memory = []
        self.num_actions = model.output_shape[-1]

    def remember(self, episode):
        """Store an episode in memory.
        
        episode: [state, action, reward, next_state, game_status]
        """
        self.memory.append(episode)
        if len(self.memory) > self.max_memory:
            del self.memory[0]

    def predict(self, state):
        """Predict Q-values for a given state using the main model."""
        state = np.asarray(state, dtype=np.float32)
        if state.ndim == 1:
            state = np.expand_dims(state, axis=0)
        return self.model.predict(state, verbose=0)

    def get_data(self, data_size=10):
        """Sample a batch of episodes and prepare training data.
        
        Returns:
            inputs: states for training
            targets: target Q-values
        """
        env_size = self.memory[0][0].shape[1]  # state size
        mem_size = len(self.memory)
        data_size = min(mem_size, data_size)
        
        inputs = np.zeros((data_size, env_size), dtype=np.float32)
        targets = np.zeros((data_size, self.num_actions), dtype=np.float32)
        
        # Sample random episodes
        indices = random.sample(range(mem_size), data_size)
        
        for i, idx in enumerate(indices):
            state, action, reward, next_state, game_status = self.memory[idx]
            
            state = np.asarray(state, dtype=np.float32)
            next_state = np.asarray(next_state, dtype=np.float32)
            
            if state.ndim > 1:
                state = state.flatten()
            if next_state.ndim > 1:
                next_state = next_state.flatten()
            
            inputs[i] = state
            
            # Get current Q-values
            targets[i] = self.model.predict(state.reshape(1, -1), verbose=0)[0]
            
            # Update Q-value for the action taken
            if game_status == 'win':
                targets[i, action] = reward
            elif game_status == 'lose':
                targets[i, action] = reward
            else:
                # Use target model for stability (Double DQN approach)
                next_q = self.target_model.predict(next_state.reshape(1, -1), verbose=0)[0]
                targets[i, action] = reward + self.discount * np.max(next_q)
        
        return inputs, targets

    def __len__(self):
        return len(self.memory)
