# Design Defense: Pirate Intelligent Agent

**Ibrahim H Jaber**

**CS 370: Current/Emerging Trends in Computer Science**

**February 2026**

---

## Introduction

For this project, I made a pirate agent that can find treasure in a maze. The pirate is like a video game character that learns on its own. It does not know where the treasure is at first. It has to try different paths and learn from its mistakes. This is called reinforcement learning. In this paper, I will explain how the pirate learns, how it is different from how a human would solve the maze, and why I chose to use Q-learning for this problem.

---

## How a Human Would Solve This Maze

If I had to solve this maze myself, I would look at the whole thing first. I can see where the walls are and where the open paths are. I would find the treasure location (bottom right corner) and try to plan a path from my starting spot to the treasure. If I hit a dead end, I would go back and try a different way.

Humans are good at this because we can see the big picture. We use our eyes to look at everything at once. We also remember when we tried something that did not work. We can plan ahead and think about what might happen before we move. This is called using prior knowledge and spatial reasoning (Russell & Norvig, 2021).

---

## How the Pirate Agent Solves the Maze

The pirate agent works very differently. It cannot see the whole maze like we can. It only knows where it is right now and what moves it can make. It does not know where the treasure is until it finds it.

The pirate learns by trying things over and over. Each time it plays the game, it remembers what happened. When it finds the treasure, it gets a reward (+1 point). When it hits a wall or takes too long, it gets a penalty (negative points). After many games, the pirate learns which moves are good and which are bad.

This is called trial and error learning. The pirate tries random moves at first. Then it starts to remember which moves gave it good rewards. Over time, it stops making random moves and starts using what it learned (Sutton & Barto, 2018).

---

## Similarities and Differences

Both humans and the pirate agent learn from experience. If something works, we do it again. If something fails, we try something else. This is similar.

But there are big differences too. Humans can learn a maze in just a few tries. The pirate agent needs hundreds or thousands of tries. However, the pirate never gets tired or bored. It can practice all day without stopping. Also, the pirate does not forget what it learned. It stores everything in a table called the Q-table.

Another difference is that humans use intuition. We can guess that moving toward the treasure is probably good. The pirate has no intuition. It has to learn everything from scratch (Mnih et al., 2015).

---

## Exploration vs Exploitation

One important idea in reinforcement learning is the balance between exploration and exploitation. Exploration means trying new things to see what happens. Exploitation means using what you already know works.

At the start of training, the pirate explores a lot. It makes random moves about 100% of the time. This is important because it needs to discover all the different paths in the maze. If it only used what it knew (which is nothing at first), it would get stuck.

As training goes on, the pirate explores less and exploits more. By the end, it only explores about 1% of the time. This is called epsilon decay. I used a decay rate of 0.995, which means epsilon gets smaller by 0.5% each episode.

For this maze problem, I think this balance is good. The pirate needs enough exploration to find the treasure from all 50 starting positions. But it also needs to start using good paths once it finds them. If it explored forever, it would never get better. If it stopped exploring too early, it might miss some good paths (Sutton & Barto, 2018).

---

## How Reinforcement Learning Finds the Path

The pirate uses a method called Q-learning to find the best path. Here is how it works in simple terms:

1. The pirate has a big table with one row for each spot in the maze (64 spots) and one column for each move (4 moves: left, up, right, down).

2. At first, all the numbers in the table are zero. The pirate does not know anything yet.

3. When the pirate makes a move and gets a reward, it updates the table. The update formula is:

   Q(state, action) = Q(state, action) + learning_rate × (reward + discount × best_future_Q - Q(state, action))

4. The learning rate (alpha = 0.2) controls how fast the pirate learns. The discount factor (gamma = 0.9) controls how much the pirate cares about future rewards.

5. After many episodes, the Q-table fills up with good values. The pirate can look at the table and pick the move with the highest Q-value. This is the best move according to what it learned.

The reward structure is also important. I used these rewards:
- +1.0 for finding the treasure (this is very good)
- -0.04 for each step (this makes the pirate want to be fast)
- -0.25 for going back to a spot it already visited (this stops loops)
- -0.75 for trying to walk into a wall (this teaches valid moves)

These rewards help the pirate learn that finding treasure quickly is the best strategy (Russell & Norvig, 2021).

---

## My Deep Q-Learning Implementation

For this project, I used a tabular Q-learning approach. The maze is 8×8, so there are 64 possible states. With 4 actions, the Q-table has 64 × 4 = 256 values to learn.

Here are the key parts of my implementation:

**Epsilon-Greedy Selection:** The pirate picks a random action with probability epsilon, or the best known action with probability 1-epsilon. This balances exploration and exploitation.

**Q-Learning Update:** After each action, the pirate updates the Q-table using the formula I showed above. This is called temporal difference learning.

**Early Stopping:** The training stops early if the pirate achieves a high win rate and passes the completion check. This saves time.

**Results:** My pirate solved the maze at episode 501. It trained in only 0.6 seconds. The completion check showed 50/50 success, meaning the pirate can find the treasure from every starting position.

---

## Conclusion

In this project, I learned how reinforcement learning works. The pirate agent is very different from a human. It cannot see the whole maze or plan ahead. But it can learn from thousands of tries without getting tired.

The key ideas are exploration vs exploitation, Q-values, and reward shaping. By using these ideas, I made a pirate that always finds the treasure. This shows that machine learning can solve problems even when the agent starts with no knowledge.

I think reinforcement learning is very useful for games and robots. It can learn things that are hard to program by hand. The agent just needs to try things and learn from the rewards.

---

## References

Mnih, V., Kavukcuoglu, K., Silver, D., Rusu, A. A., Veness, J., Bellemare, M. G., Graves, A., Riedmiller, M., Fidjeland, A. K., Ostrovski, G., Petersen, S., Beattie, C., Sadik, A., Antonoglou, I., King, H., Kumaran, D., Wierstra, D., Legg, S., & Hassabis, D. (2015). Human-level control through deep reinforcement learning. *Nature*, 518(7540), 529-533. https://doi.org/10.1038/nature14236

Russell, S., & Norvig, P. (2021). *Artificial intelligence: A modern approach* (4th ed.). Pearson.

Sutton, R. S., & Barto, A. G. (2018). *Reinforcement learning: An introduction* (2nd ed.). MIT Press.
