"""
TreasureMaze.py - Treasure Hunt Game Environment

This class represents the maze environment for the pirate treasure hunt game.
The maze is represented as a numpy array where:
- 1.0 = free cell (passable)
- 0.0 = blocked cell (wall/obstacle)
The treasure is always at the bottom-right corner (nrows-1, ncols-1).
The pirate starts at a specified cell and must navigate to the treasure.
"""

import numpy as np

# Actions
LEFT = 0
UP = 1
RIGHT = 2
DOWN = 3

class TreasureMaze:
    def __init__(self, maze, pirate=(0, 0)):
        self._maze = np.array(maze)
        nrows, ncols = self._maze.shape
        self.target = (nrows - 1, ncols - 1)  # treasure location
        self.free_cells = [(r, c) for r in range(nrows) for c in range(ncols) if self._maze[r, c] == 1.0]
        self.free_cells.remove(self.target)
        if self._maze[self.target] == 0.0:
            raise ValueError("Invalid maze: target cell is blocked!")
        if pirate not in self.free_cells:
            raise ValueError("Invalid pirate location: must be a free cell")
        self.reset(pirate)

    def reset(self, pirate=None):
        """Reset the maze to initial state with pirate at given cell."""
        if pirate is None:
            pirate = self.free_cells[np.random.randint(len(self.free_cells))]
        self.pirate = pirate
        self.maze = np.copy(self._maze)
        nrows, ncols = self.maze.shape
        row, col = pirate
        self.maze[row, col] = 0.5  # mark pirate position
        self.state = (row, col, 'start')
        self.min_reward = -0.5 * self.maze.size
        self.total_reward = 0
        self.visited = set()

    def update_state(self, action):
        """Update the state based on action taken."""
        nrows, ncols = self.maze.shape
        pirate_row, pirate_col, mode = self.state

        if self.maze[pirate_row, pirate_col] > 0.0:
            self.visited.add((pirate_row, pirate_col))

        valid_actions = self.valid_actions()

        if not valid_actions:
            mode = 'blocked'
        elif action in valid_actions:
            mode = 'valid'
            if action == LEFT:
                pirate_col -= 1
            elif action == UP:
                pirate_row -= 1
            elif action == RIGHT:
                pirate_col += 1
            elif action == DOWN:
                pirate_row += 1
        else:
            mode = 'invalid'

        self.state = (pirate_row, pirate_col, mode)

    def get_reward(self):
        """Return reward based on current state."""
        pirate_row, pirate_col, mode = self.state
        nrows, ncols = self.maze.shape

        if pirate_row == nrows - 1 and pirate_col == ncols - 1:
            return 1.0  # treasure found!
        if mode == 'blocked':
            return self.min_reward - 1
        if (pirate_row, pirate_col) in self.visited:
            return -0.25  # penalty for revisiting
        if mode == 'invalid':
            return -0.75  # penalty for invalid move
        if mode == 'valid':
            return -0.04  # small penalty for each step

        return 0.0

    def act(self, action):
        """Execute action and return (state, reward, game_status)."""
        self.update_state(action)
        reward = self.get_reward()
        self.total_reward += reward
        status = self.game_status()
        envstate = self.observe()
        return envstate, reward, status

    def observe(self):
        """Return the current maze state as a flattened array."""
        canvas = self.draw_env()
        envstate = canvas.reshape((1, -1))
        return envstate

    def draw_env(self):
        """Draw the current state of the maze."""
        canvas = np.copy(self.maze)
        nrows, ncols = self.maze.shape
        # Clear the pirate's previous position
        for r in range(nrows):
            for c in range(ncols):
                if canvas[r, c] > 0.0:
                    canvas[r, c] = 1.0
        # Mark visited cells
        for r, c in self.visited:
            canvas[r, c] = 0.6
        # Mark pirate's current position
        row, col, _ = self.state
        canvas[row, col] = 0.5
        return canvas

    def game_status(self):
        """Return 'win', 'lose', or 'not_over'."""
        if self.total_reward < self.min_reward:
            return 'lose'
        pirate_row, pirate_col, _ = self.state
        nrows, ncols = self.maze.shape
        if pirate_row == nrows - 1 and pirate_col == ncols - 1:
            return 'win'
        return 'not_over'

    def valid_actions(self, cell=None):
        """Return list of valid actions from current or specified cell."""
        if cell is None:
            row, col, _ = self.state
        else:
            row, col = cell
        actions = []
        nrows, ncols = self.maze.shape
        if col > 0 and self.maze[row, col - 1] != 0.0:
            actions.append(LEFT)
        if row > 0 and self.maze[row - 1, col] != 0.0:
            actions.append(UP)
        if col < ncols - 1 and self.maze[row, col + 1] != 0.0:
            actions.append(RIGHT)
        if row < nrows - 1 and self.maze[row + 1, col] != 0.0:
            actions.append(DOWN)
        return actions

    @property
    def maze(self):
        return self._maze_canvas

    @maze.setter
    def maze(self, value):
        self._maze_canvas = value
